import React from 'react'

export default function Comics() {
    return (
        <div>Comics</div>
    )
}
